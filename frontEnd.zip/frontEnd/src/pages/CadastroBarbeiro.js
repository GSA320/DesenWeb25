import GlobalStyle from "../styles/global";
import styled from "styled-components";
import Form from "../components/Form.js";
import Grid from "../components/Grid.js";
import { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: flex-start; /* começa do topo */
  align-items: center;
  gap: 10px;
  box-sizing: border-box;
  padding: 40px 20px 0 20px; 
`;

const Title = styled.h2``;

function CadastroBarbeiro() {
  const [barbeiro, setBarbeiro] = useState([]); // Inicia como um array vazio
  const [onEdit, setOnEdit] = useState(null);
  const [loading, setLoading] = useState(false); // Estado de carregamento

  const getBarbeiros = async () => {
    setLoading(true); // Inicia o carregamento
    try {
      const res = await axios.get("http://localhost:8800/barbeiros");
      setBarbeiro(res.data.sort((a, b) => (a.nome > b.nome ? 1 : -1))); // Ordenando os barbeiros por nome
    } catch (error) {
      toast.error("Erro ao carregar os barbeiros: " + error.message);
    } finally {
      setLoading(false); // Finaliza o carregamento
    }
  };

  useEffect(() => {
    getBarbeiros(); // Chama a função ao carregar o componente
  }, []); 

  return (
    <>
      <h1 style={{ color: "black" }}></h1>
      <Container>
        <Title>Barbeiros</Title>
        {/* Passando as funções de edição e dados dos barbeiros para o Form */}
        <Form onEdit={onEdit} setOnEdit={setOnEdit} getBarbeiros={getBarbeiros} />
        
        {/* Exibindo indicador de carregamento ou os barbeiros */}
        {loading ? (
          <p>Carregando...</p>
        ) : barbeiro.length === 0 ? (
          <p>Nenhum barbeiro encontrado</p>
        ) : (
          <Grid barbeiro={barbeiro} setBarbeiro={setBarbeiro} setOnEdit={setOnEdit} />
        )}
      </Container>
      <ToastContainer autoClose={3000} position="bottom-left" />
      <GlobalStyle />
    </>
  );
}

export default CadastroBarbeiro;
