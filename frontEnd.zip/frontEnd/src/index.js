import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import App from './App';
import CadastroBarbeiro from './pages/CadastroBarbeiro';

// Definindo as rotas corretamente
const router = createBrowserRouter([
  {
    path: "/",
    element: <App /> 
  },
  {
    path: "/CadastroBarbeiro",  // Rota única para a página de cadastro
    element: <CadastroBarbeiro />  // Roteando para o CadastroBarbeiro
  }
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />  {/* Envolvendo a aplicação com RouterProvider */}
  </React.StrictMode>
);
